// each of my star postions
export const STAR_POSITIONS = [
  { x: 285, y: 110},     // star 1 (top)
  { x: 190,   y: 185 },   // star 2
  { x: 233,  y: 293 },   // star 3
  { x: 105,   y: 355 },   // star 4
  { x: 240,  y: 395 },   // star 5
  { x: 171,  y: 485 },   // star 6
  { x: 235,   y: 593 },   // star 7
  { x: 90, y: 663},   // star 8 (bottom)
];

